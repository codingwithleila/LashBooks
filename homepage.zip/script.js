// Automatic Slideshow - change image every 4 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  // Hide all slides
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  myIndex++;
  // Reset index if it exceeds the number of slides
  if (myIndex > x.length) {myIndex = 1}
  // Display the current slide
  x[myIndex-1].style.display = "block";
  // Change image every 4 seconds
  setTimeout(carousel, 4000);
}

function myFunction() {
  var x = document.getElementById("navDemo");
  // Toggle the "w3-show" class to show/hide the navigation menu
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

function toggleMore() {
  var x = document.getElementById("moreMenu");
  // Toggle the "w3-show" class to show/hide the "More" menu
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

document.addEventListener('DOMContentLoaded', function() {
  // Get references to DOM elements
  const calendar = document.getElementById('calendar');
  const monthYear = document.getElementById('month-year');
  const nextMonth = document.getElementById('next-month');
  const prevMonth = document.getElementById('prev-month');

  // Initialize the current date
  let currentDate = new Date();

  // Function to render the calendar for a given date
  function renderCalendar(date) {
    // Clear the current calendar
    calendar.innerHTML = '';
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();

    // Display the current month and year
    monthYear.textContent = date.toLocaleDateString('default', { month: 'long', year: 'numeric' });

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      const emptyCell = document.createElement('div');
      calendar.appendChild(emptyCell);
    }

    // Add cells for each day of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dayElement = document.createElement('div');
      dayElement.className = 'day';
      dayElement.innerHTML = `<span class="day-number">${day}</span>`;

      // Highlight today's date
      if (year === today.getFullYear() && month === today.getMonth() && day === today.getDate()) {
        dayElement.classList.add('today');
      }

      // Mark weekends and future dates as 'OPEN'
      const dayOfWeek = new Date(year, month, day).getDay();
      if (dayOfWeek === 5 || dayOfWeek === 6 || dayOfWeek === 0) { // Friday, Saturday, Sunday
        const currentDate = new Date(year, month, day);
        if (currentDate >= today) {
          const availableText = document.createElement('div');
          availableText.className = 'available';
          availableText.textContent = 'OPEN';
          dayElement.appendChild(availableText);
        }
      }

      // Append the day element to the calendar
      calendar.appendChild(dayElement);
    }
  }

  // Event listener for the next month button
  nextMonth.addEventListener('click', function() {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar(currentDate);
  });

  // Event listener for the previous month button
  prevMonth.addEventListener('click', function() {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar(currentDate);
  });

  // Initial render of the calendar
  renderCalendar(currentDate);
});
